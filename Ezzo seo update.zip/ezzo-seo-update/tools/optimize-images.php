<?php
/**
 * One-time image optimizer for Ezzo.sg.
 *
 * Run from the website root:
 *   php tools/optimize-images.php
 *
 * Or provide another image directory:
 *   php tools/optimize-images.php /full/path/to/public_html/assets/images
 *
 * The script keeps original files and creates same-name WebP/AVIF files plus
 * 480, 768, 1200 and 1600 pixel variants. The responsive_image() helper will
 * discover and serve the generated files automatically.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
    fwrite(STDERR, "GD with WebP support is required. Ask the host to enable php-gd.\n");
    exit(1);
}

$root = realpath($argv[1] ?? dirname(__DIR__) . '/assets/images');

if ($root === false || !is_dir($root)) {
    fwrite(STDERR, "Image directory not found.\n");
    exit(1);
}

function optimizer_is_image($image): bool
{
    return is_resource($image)
        || (is_object($image) && get_class($image) === 'GdImage');
}

function optimizer_canvas(int $width, int $height)
{
    $canvas = imagecreatetruecolor($width, $height);

    if (!$canvas) {
        return false;
    }

    imagealphablending($canvas, false);
    imagesavealpha($canvas, true);
    $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
    imagefill($canvas, 0, 0, $transparent);

    return $canvas;
}

function optimizer_resize($source, int $targetWidth)
{
    $sourceWidth = imagesx($source);
    $sourceHeight = imagesy($source);
    $targetWidth = min($targetWidth, $sourceWidth);
    $targetHeight = max(1, (int) round($sourceHeight * ($targetWidth / $sourceWidth)));
    $canvas = optimizer_canvas($targetWidth, $targetHeight);

    if (!optimizer_is_image($canvas)) {
        return false;
    }

    imagecopyresampled(
        $canvas,
        $source,
        0,
        0,
        0,
        0,
        $targetWidth,
        $targetHeight,
        $sourceWidth,
        $sourceHeight
    );

    return $canvas;
}

function optimizer_write($image, string $path, string $format): bool
{
    $temporary = $path . '.tmp';
    $ok = false;

    if ($format === 'webp') {
        $ok = imagewebp($image, $temporary, 82);
    } elseif ($format === 'avif' && function_exists('imageavif')) {
        $ok = @imageavif($image, $temporary, 55);
    }

    if (!$ok) {
        @unlink($temporary);
        return false;
    }

    return rename($temporary, $path);
}

$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);

$processed = 0;
$created = 0;
$skipped = 0;
$widths = [480, 768, 1200, 1600];

foreach ($iterator as $fileInfo) {
    if (!$fileInfo->isFile()) {
        continue;
    }

    $path = $fileInfo->getPathname();
    $extension = strtolower($fileInfo->getExtension());

    if (!in_array($extension, ['jpg', 'jpeg', 'png', 'webp'], true)) {
        continue;
    }

    // Do not process variants created by this script again.
    if (preg_match('/-\d+$/', pathinfo($path, PATHINFO_FILENAME))) {
        continue;
    }

    $binary = @file_get_contents($path);
    $image = $binary !== false ? @imagecreatefromstring($binary) : false;

    if (!optimizer_is_image($image)) {
        fwrite(STDERR, "Skipped unreadable image: {$path}\n");
        $skipped++;
        continue;
    }

    $sourceWidth = imagesx($image);
    $sourceHeight = imagesy($image);

    if ($sourceWidth <= 0 || $sourceHeight <= 0 || ($sourceWidth * $sourceHeight) > 50_000_000) {
        fwrite(STDERR, "Skipped oversized/invalid image: {$path}\n");
        imagedestroy($image);
        $skipped++;
        continue;
    }

    $processed++;
    $directory = dirname($path);
    $base = pathinfo($path, PATHINFO_FILENAME);
    $mainWidth = min(2000, $sourceWidth);
    $main = optimizer_resize($image, $mainWidth);

    if (optimizer_is_image($main)) {
        $webpPath = $directory . DIRECTORY_SEPARATOR . $base . '.webp';

        if ($extension !== 'webp' || realpath($webpPath) !== realpath($path)) {
            if (optimizer_write($main, $webpPath, 'webp')) {
                $created++;
            }
        }

        if (function_exists('imageavif')) {
            $avifPath = $directory . DIRECTORY_SEPARATOR . $base . '.avif';
            if (optimizer_write($main, $avifPath, 'avif')) {
                $created++;
            }
        }

        imagedestroy($main);
    }

    foreach ($widths as $width) {
        if ($width >= $sourceWidth) {
            continue;
        }

        $variant = optimizer_resize($image, $width);

        if (!optimizer_is_image($variant)) {
            continue;
        }

        $webpVariant = $directory . DIRECTORY_SEPARATOR . $base . '-' . $width . '.webp';
        if (optimizer_write($variant, $webpVariant, 'webp')) {
            $created++;
        }

        if (function_exists('imageavif')) {
            $avifVariant = $directory . DIRECTORY_SEPARATOR . $base . '-' . $width . '.avif';
            if (optimizer_write($variant, $avifVariant, 'avif')) {
                $created++;
            }
        }

        imagedestroy($variant);
    }

    imagedestroy($image);
    echo "Optimized: {$path}\n";
}

echo "\nProcessed originals: {$processed}\n";
echo "Created modern files: {$created}\n";
echo "Skipped: {$skipped}\n";
