# Ezzo.sg SEO and Performance Update

This package updates the PHP/MySQL website files supplied for review.

## Files to deploy

Copy the files to the matching locations in the website root:

- `index.php`
- `.htaccess`
- `includes/functions.php`
- `includes/header.php`
- `assets/css/style.css`

Back up the current website and database before replacing files.

## Important configuration

The code assumes the production domain is `https://www.ezzo.sg`.

For a configurable value, add this to `config.php`:

```php
define('PRODUCTION_SITE_URL', 'https://www.ezzo.sg');
```

The preview hostname `preview-ezzo.ezzogenics.com` receives both:

- a `noindex, nofollow, noarchive` meta directive; and
- an `X-Robots-Tag` HTTP response header.

The production canonical URLs continue to point to `https://www.ezzo.sg`.

## Existing image conversion

The display helper automatically uses same-name AVIF/WebP files and responsive variants when they exist. New admin uploads are re-encoded to modern formats when PHP GD is available.

To create modern variants for existing images, run from the website root:

```bash
php tools/optimize-images.php
```

The script:

- keeps original JPG/PNG/WebP files;
- creates WebP files;
- creates AVIF files when supported by PHP GD;
- creates 480, 768, 1200 and 1600 pixel variants; and
- strips embedded metadata by re-encoding.

If the script reports that GD/WebP is unavailable, ask the hosting provider to enable the `php-gd` extension.

## Deployment order

1. Back up the live files.
2. Upload the files in this package to the preview website.
3. Confirm that navigation, forms, project cards and product cards work.
4. Run `php tools/optimize-images.php` on the preview server.
5. Clear the hosting/CDN cache.
6. Test the preview with PageSpeed Insights or Lighthouse on mobile.
7. Deploy the same files and generated image variants to production.
8. Keep the preview-domain noindex protection enabled after launch.

## Behaviour changes

- CSS and Google Fonts load asynchronously after a small critical CSS block.
- CSS cache busting now uses `filemtime()` rather than `time()`, allowing browser caching.
- Homepage images receive intrinsic dimensions, lazy loading and responsive `srcset` when variants are available.
- The hero image loads eagerly with high fetch priority.
- Preview pages are excluded from indexing.
- Canonicals use the production domain.
- Fake fallback testimonials were removed. The testimonial section appears only when approved database testimonials exist.
- Future image uploads are validated and converted to WebP/AVIF variants when PHP GD supports them.

## Server requirements

- PHP 7.4 or later
- Apache 2.4 recommended
- `mod_rewrite`
- `mod_headers`
- `mod_expires`
- `mod_deflate` or `mod_brotli`
- PHP GD with WebP support recommended
